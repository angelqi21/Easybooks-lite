# EasyBooks Lite | 轻账本 (PWA)

A lightweight bilingual personal bookkeeping app with income/expense entry, monthly summary, search, CSV import/export, and offline caching.

## Important data note
The first version stores transactions in the browser's local storage on the device/browser where you use it. It does **not** sync automatically with Google Sheets or another device. Export a CSV backup regularly. Avoid using it as the sole record store for important company accounts until backup and data storage needs are assessed.

## Publish free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new **public** repository named `easybooks-lite`.
3. Upload all four app files: `index.html`, `manifest.json`, `sw.js`, `icon.svg` (README is optional).
4. Open the repository's **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
6. Wait for GitHub Pages to publish the site. The URL will look like `https://YOUR-USERNAME.github.io/easybooks-lite/`.
7. Open that HTTPS URL on your phone.

## Add to home screen
- iPhone: open the URL in Safari → Share → Add to Home Screen → Add.
- Android: open the URL in Chrome → menu (⋮) → Install app or Add to Home screen.

## Updates
When you change files in GitHub, Pages republishes the site. If the app is already installed, close and reopen it to receive updates.
